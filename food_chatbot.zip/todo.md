# Food Ordering Chatbot - TODO

## Phase 1: Database & Schema
- [x] Create menu_items table with name, description, image_url, price, category
- [x] Create orders table with user_id, total_price, discount_amount, status
- [x] Create order_items table with order_id, menu_item_id, quantity, price_at_order
- [x] Create discounts table with code, discount_type, discount_value, active status
- [x] Create chat_messages table with user_id, order_id, message_type, content
- [x] Generate and apply database migrations

## Phase 2: Backend API
- [x] Create tRPC procedure to fetch all menu items
- [x] Create tRPC procedure to get menu items by category
- [x] Create tRPC procedure to handle chat messages
- [x] Create tRPC procedure to create orders
- [x] Create tRPC procedure to add items to order
- [x] Create tRPC procedure to apply discount codes
- [x] Create tRPC procedure to calculate order total with discounts
- [x] Create tRPC procedure to fetch order history
- [x] Seed database with sample menu items and discounts

## Phase 3: Frontend - Chat Interface
- [x] Create elegant chat container component with message bubbles
- [x] Implement message input field with send button
- [x] Add message history display (user and bot messages)
- [x] Create message bubble styling (different styles for user vs bot)
- [x] Implement auto-scroll to latest message
- [x] Add loading state for bot responses

## Phase 4: Frontend - Menu Display
- [x] Create menu card component with image, name, description, price
- [x] Implement menu grid layout (responsive)
- [x] Create category filter buttons
- [x] Add "Add to Order" button with quantity selector
- [x] Implement menu item modal/detail view
- [x] Add smooth animations and hover effects

## Phase 5: Frontend - Order Summary & Pricing
- [x] Create order summary panel showing selected items
- [x] Implement quantity adjustment in order summary
- [x] Create discount code input field
- [x] Implement real-time price calculation with discounts
- [x] Display breakdown: subtotal, discount, tax (if applicable), total
- [x] Create checkout/confirm order button
- [x] Add order confirmation modal

## Phase 6: Styling & UX
- [x] Apply elegant color scheme (modern, sophisticated)
- [x] Implement responsive design for mobile/tablet/desktop
- [x] Add smooth transitions and animations
- [x] Create consistent typography and spacing
- [x] Implement dark/light theme support (optional)
- [x] Add icons for better visual hierarchy
- [x] Ensure accessibility (ARIA labels, keyboard navigation)

## Phase 7: Integration & Testing
- [x] Connect chat interface to backend
- [x] Test menu fetching and display
- [x] Test order creation and item addition
- [x] Test discount application and price calculation
- [x] Test responsive design across devices
- [x] Write vitest tests for critical functions
- [x] Fix any bugs and edge cases

## Phase 8: Deployment
- [x] Create checkpoint for final version
- [x] Prepare for publishing

## Bug Fixes & Enhancements
- [x] Fix chat message backend connection - added chat history query to frontend
- [x] Verify tRPC chat.sendMessage mutation is working correctly
- [x] Test chat history persistence in database
- [x] Add chat history query to frontend to load messages from SQL database
- [x] Create comprehensive chat functionality tests (14 tests passing)
- [x] Verify all 34 tests passing (19 pricing + 14 chat + 1 auth)
