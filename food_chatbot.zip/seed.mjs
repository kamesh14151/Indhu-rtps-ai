import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { menuItems, discounts } from "./drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

async function seed() {
  if (!DATABASE_URL) {
    console.error("DATABASE_URL not set");
    process.exit(1);
  }

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  console.log("🌱 Seeding database...");

  // Sample menu items
  const sampleMenuItems = [
    {
      name: "Margherita Pizza",
      description: "Classic pizza with fresh mozzarella, basil, and tomato sauce",
      category: "Mains",
      price: "12.99",
      imageUrl: "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=400",
      available: true,
    },
    {
      name: "Caesar Salad",
      description: "Crisp romaine lettuce with parmesan, croutons, and creamy Caesar dressing",
      category: "Appetizers",
      price: "8.99",
      imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400",
      available: true,
    },
    {
      name: "Grilled Salmon",
      description: "Fresh Atlantic salmon fillet with lemon butter sauce and seasonal vegetables",
      category: "Mains",
      price: "18.99",
      imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400",
      available: true,
    },
    {
      name: "Chocolate Lava Cake",
      description: "Warm chocolate cake with molten center, served with vanilla ice cream",
      category: "Desserts",
      price: "7.99",
      imageUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400",
      available: true,
    },
    {
      name: "Garlic Bread",
      description: "Toasted bread with garlic butter and fresh parsley",
      category: "Appetizers",
      price: "4.99",
      imageUrl: "https://images.unsplash.com/photo-1599599810694-b5ac4dd64b73?w=400",
      available: true,
    },
    {
      name: "Iced Latte",
      description: "Cold espresso with smooth milk and ice",
      category: "Beverages",
      price: "5.99",
      imageUrl: "https://images.unsplash.com/photo-1517668808822-9ebb02ae2a0e?w=400",
      available: true,
    },
    {
      name: "Burger Deluxe",
      description: "Juicy beef patty with cheddar, bacon, lettuce, tomato, and special sauce",
      category: "Mains",
      price: "14.99",
      imageUrl: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400",
      available: true,
    },
    {
      name: "Tiramisu",
      description: "Italian dessert with layers of mascarpone cream and coffee-soaked ladyfingers",
      category: "Desserts",
      price: "6.99",
      imageUrl: "https://images.unsplash.com/photo-1571115764595-644a12c7cb72?w=400",
      available: true,
    },
  ];

  // Sample discounts
  const sampleDiscounts = [
    {
      code: "WELCOME10",
      description: "10% off for new customers",
      discountType: "percentage",
      discountValue: "10",
      maxDiscount: null,
      minOrderAmount: "20",
      active: true,
      expiresAt: null,
    },
    {
      code: "SAVE5",
      description: "$5 off any order",
      discountType: "fixed",
      discountValue: "5",
      maxDiscount: null,
      minOrderAmount: "15",
      active: true,
      expiresAt: null,
    },
    {
      code: "SUMMER20",
      description: "20% off summer special",
      discountType: "percentage",
      discountValue: "20",
      maxDiscount: "15",
      minOrderAmount: "30",
      active: true,
      expiresAt: null,
    },
  ];

  try {
    // Insert menu items
    console.log("📝 Inserting menu items...");
    for (const item of sampleMenuItems) {
      await db.insert(menuItems).values(item);
    }
    console.log(`✅ Inserted ${sampleMenuItems.length} menu items`);

    // Insert discounts
    console.log("🎟️ Inserting discount codes...");
    for (const discount of sampleDiscounts) {
      await db.insert(discounts).values(discount);
    }
    console.log(`✅ Inserted ${sampleDiscounts.length} discount codes`);

    console.log("🎉 Seeding completed successfully!");
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seed();
