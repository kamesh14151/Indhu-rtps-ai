import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Menu endpoints
  menu: router({
    getAll: publicProcedure.query(async () => {
      return db.getAllMenuItems();
    }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return db.getMenuItemsByCategory(input.category);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getMenuItemById(input.id);
      }),
  }),

  // Discount endpoints
  discount: router({
    validate: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        const discount = await db.getDiscountByCode(input.code);
        if (!discount) {
          return { valid: false, discount: null };
        }
        return { valid: true, discount };
      }),

    getAll: publicProcedure.query(async () => {
      return db.getAllDiscounts();
    }),
  }),

  // Order endpoints
  order: router({
    create: protectedProcedure
      .input(z.object({
        items: z.array(z.object({
          menuItemId: z.number(),
          quantity: z.number().min(1),
        })),
        discountCode: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");

        // Calculate subtotal
        let subtotal = 0;
        const orderItemsData = [];

        for (const item of input.items) {
          const menuItem = await db.getMenuItemById(item.menuItemId);
          if (!menuItem) throw new Error(`Menu item ${item.menuItemId} not found`);

          const itemTotal = parseFloat(menuItem.price) * item.quantity;
          subtotal += itemTotal;
          orderItemsData.push({
            menuItemId: item.menuItemId,
            quantity: item.quantity,
            priceAtOrder: menuItem.price,
          });
        }

        // Apply discount if provided
        let discountAmount = 0;
        if (input.discountCode) {
          const discount = await db.getDiscountByCode(input.discountCode);
          if (discount) {
            if (discount.minOrderAmount && subtotal < parseFloat(discount.minOrderAmount)) {
              throw new Error(`Minimum order amount of ${discount.minOrderAmount} required for this discount`);
            }

            if (discount.discountType === "percentage") {
              discountAmount = (subtotal * parseFloat(discount.discountValue)) / 100;
              if (discount.maxDiscount) {
                discountAmount = Math.min(discountAmount, parseFloat(discount.maxDiscount));
              }
            } else {
              discountAmount = parseFloat(discount.discountValue);
            }
          }
        }

        const totalPrice = subtotal - discountAmount;

        // Create order
        const result = await db.createOrder(
          ctx.user.id,
          subtotal.toString(),
          discountAmount.toString(),
          totalPrice.toString(),
          input.discountCode
        );

        // Get the inserted order ID
        const orderId = (result as any).insertId;

        // Add order items
        for (const item of orderItemsData) {
          await db.addOrderItem(orderId, item.menuItemId, item.quantity, item.priceAtOrder);
        }

        return {
          orderId,
          subtotal,
          discountAmount,
          totalPrice,
        };
      }),

    getById: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");

        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }

        const items = await db.getOrderItems(input.orderId);
        return { order, items };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("User not authenticated");
      return db.getUserOrders(ctx.user.id);
    }),

    updateStatus: protectedProcedure
      .input(z.object({ orderId: z.number(), status: z.enum(["pending", "confirmed", "preparing", "completed", "cancelled"]) }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");

        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }

        return db.updateOrderStatus(input.orderId, input.status);
      }),
  }),

  // Chat endpoints
  chat: router({
    sendMessage: protectedProcedure
      .input(z.object({
        content: z.string(),
        orderId: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");

        // Save user message
        await db.saveChatMessage(ctx.user.id, "user", input.content, input.orderId);

        // Generate bot response
        let botResponse = "";
        const lowerContent = input.content.toLowerCase();

        if (lowerContent.includes("menu") || lowerContent.includes("food") || lowerContent.includes("items")) {
          botResponse = "I can help you browse our menu! Would you like to see items from a specific category like appetizers, mains, desserts, or beverages?";
        } else if (lowerContent.includes("price") || lowerContent.includes("cost")) {
          botResponse = "Each item has its price displayed. You can also apply a discount code at checkout to get a better deal!";
        } else if (lowerContent.includes("discount") || lowerContent.includes("promo") || lowerContent.includes("code")) {
          botResponse = "Great! Do you have a discount code? I can help you apply it to your order for savings.";
        } else if (lowerContent.includes("order") || lowerContent.includes("checkout")) {
          botResponse = "Perfect! Let me help you complete your order. You can review your items and apply any discount codes before confirming.";
        } else if (lowerContent.includes("thank") || lowerContent.includes("thanks")) {
          botResponse = "You're welcome! Is there anything else I can help you with?";
        } else {
          botResponse = "I'm here to help you order delicious food! You can browse our menu, select items, apply discounts, and checkout. What would you like to do?";
        }

        // Save bot response
        await db.saveChatMessage(ctx.user.id, "bot", botResponse, input.orderId);

        return { userMessage: input.content, botResponse };
      }),

    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");
        return db.getChatHistory(ctx.user.id, input.limit);
      }),
  }),
});

export type AppRouter = typeof appRouter;
