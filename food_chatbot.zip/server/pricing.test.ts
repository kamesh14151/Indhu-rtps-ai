import { describe, it, expect } from "vitest";

/**
 * Discount calculation logic tests
 * Tests for percentage and fixed amount discounts with max discount caps
 */

interface DiscountData {
  discountType: "percentage" | "fixed";
  discountValue: number;
  maxDiscount?: number;
  minOrderAmount?: number;
}

function calculateDiscount(subtotal: number, discount: DiscountData): number {
  if (discount.minOrderAmount && subtotal < discount.minOrderAmount) {
    throw new Error(`Minimum order amount of ${discount.minOrderAmount} required`);
  }

  let amount = 0;

  if (discount.discountType === "percentage") {
    amount = (subtotal * discount.discountValue) / 100;
    if (discount.maxDiscount) {
      amount = Math.min(amount, discount.maxDiscount);
    }
  } else {
    amount = discount.discountValue;
  }

  return amount;
}

function calculateTotal(subtotal: number, discountAmount: number): number {
  return Math.max(0, subtotal - discountAmount);
}

describe("Discount Calculation", () => {
  describe("Percentage Discounts", () => {
    it("should calculate 10% discount correctly", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
      };
      const amount = calculateDiscount(100, discount);
      expect(amount).toBe(10);
    });

    it("should calculate 20% discount with max cap", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 20,
        maxDiscount: 15,
      };
      const amount = calculateDiscount(100, discount);
      expect(amount).toBe(15); // 20% of 100 = 20, but capped at 15
    });

    it("should respect minimum order amount for percentage discount", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
        minOrderAmount: 50,
      };
      expect(() => calculateDiscount(30, discount)).toThrow(
        "Minimum order amount of 50 required"
      );
    });

    it("should calculate 15% discount on large order", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 15,
      };
      const amount = calculateDiscount(200, discount);
      expect(amount).toBe(30);
    });
  });

  describe("Fixed Amount Discounts", () => {
    it("should apply $5 fixed discount", () => {
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 5,
      };
      const amount = calculateDiscount(50, discount);
      expect(amount).toBe(5);
    });

    it("should respect minimum order amount for fixed discount", () => {
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 5,
        minOrderAmount: 20,
      };
      expect(() => calculateDiscount(15, discount)).toThrow(
        "Minimum order amount of 20 required"
      );
    });

    it("should apply $10 fixed discount on qualifying order", () => {
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 10,
        minOrderAmount: 30,
      };
      const amount = calculateDiscount(50, discount);
      expect(amount).toBe(10);
    });
  });

  describe("Order Total Calculation", () => {
    it("should calculate total with percentage discount", () => {
      const subtotal = 100;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(total).toBe(90);
    });

    it("should calculate total with fixed discount", () => {
      const subtotal = 50;
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 5,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(total).toBe(45);
    });

    it("should not allow negative totals", () => {
      const subtotal = 10;
      const discountAmount = 20;
      const total = calculateTotal(subtotal, discountAmount);
      expect(total).toBe(0);
    });

    it("should calculate complex order with max discount cap", () => {
      const subtotal = 150;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 20,
        maxDiscount: 20,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(discountAmount).toBe(20); // 20% of 150 = 30, but capped at 20
      expect(total).toBe(130);
    });
  });

  describe("Edge Cases", () => {
    it("should handle zero subtotal", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
      };
      const amount = calculateDiscount(0, discount);
      expect(amount).toBe(0);
    });

    it("should handle 0% discount", () => {
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 0,
      };
      const amount = calculateDiscount(100, discount);
      expect(amount).toBe(0);
    });

    it("should handle $0 fixed discount", () => {
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 0,
      };
      const amount = calculateDiscount(50, discount);
      expect(amount).toBe(0);
    });

    it("should calculate discount on decimal prices", () => {
      const subtotal = 19.99;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
      };
      const amount = calculateDiscount(subtotal, discount);
      expect(Math.round(amount * 100) / 100).toBe(2.0);
    });
  });

  describe("Sample Menu Scenarios", () => {
    it("WELCOME10 - 10% off for orders over $20", () => {
      const subtotal = 25;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 10,
        minOrderAmount: 20,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(discountAmount).toBe(2.5);
      expect(total).toBe(22.5);
    });

    it("SAVE5 - $5 off for orders over $15", () => {
      const subtotal = 30;
      const discount: DiscountData = {
        discountType: "fixed",
        discountValue: 5,
        minOrderAmount: 15,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(discountAmount).toBe(5);
      expect(total).toBe(25);
    });

    it("SUMMER20 - 20% off (max $15) for orders over $30", () => {
      const subtotal = 100;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 20,
        maxDiscount: 15,
        minOrderAmount: 30,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(discountAmount).toBe(15); // 20% of 100 = 20, but capped at 15
      expect(total).toBe(85);
    });

    it("SUMMER20 on small qualifying order", () => {
      const subtotal = 50;
      const discount: DiscountData = {
        discountType: "percentage",
        discountValue: 20,
        maxDiscount: 15,
        minOrderAmount: 30,
      };
      const discountAmount = calculateDiscount(subtotal, discount);
      const total = calculateTotal(subtotal, discountAmount);
      expect(discountAmount).toBe(10); // 20% of 50 = 10, which is under cap
      expect(total).toBe(40);
    });
  });
});
