import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Loader2, Send, ShoppingCart, Plus, Minus, X } from "lucide-react";
import { toast } from "sonner";

interface CartItem {
  menuItemId: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface ChatMessage {
  id: string;
  type: "user" | "bot";
  content: string;
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [showOrderSummary, setShowOrderSummary] = useState(false);
  const [discountCode, setDiscountCode] = useState("");
  const [discountAmount, setDiscountAmount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // tRPC queries and mutations
  const { data: allMenuItems, isLoading: menuLoading } = trpc.menu.getAll.useQuery();
  const { data: discountData } = trpc.discount.validate.useQuery(
    { code: discountCode },
    { enabled: discountCode.length > 0 }
  );
  const { data: chatHistory } = trpc.chat.getHistory.useQuery({ limit: 50 });
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const createOrderMutation = trpc.order.create.useMutation();

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Load chat history from database
  useEffect(() => {
    if (!authLoading && user && chatHistory) {
      if (chatHistory.length === 0) {
        const greeting: ChatMessage = {
          id: "greeting",
          type: "bot",
          content: `Welcome, ${user.name}! 👋 I'm your food ordering assistant. Browse our delicious menu, add items to your cart, and I'll help you complete your order. What would you like to eat today?`,
        };
        setMessages([greeting]);
      } else {
        const historyMessages: ChatMessage[] = chatHistory.map((msg: any) => ({
          id: msg.id?.toString() || Date.now().toString(),
          type: msg.messageType as "user" | "bot",
          content: msg.content,
        }));
        setMessages(historyMessages);
      }
    }
  }, [authLoading, user, chatHistory]);

  // Apply discount
  useEffect(() => {
    if (discountData?.valid && discountData.discount) {
      const subtotal = calculateSubtotal();
      const discount = discountData.discount;
      let amount = 0;

      if (discount.discountType === "percentage") {
        amount = (subtotal * parseFloat(discount.discountValue)) / 100;
        if (discount.maxDiscount) {
          amount = Math.min(amount, parseFloat(discount.maxDiscount));
        }
      } else {
        amount = parseFloat(discount.discountValue);
      }

      setDiscountAmount(amount);
      toast.success(`Discount applied! You save $${amount.toFixed(2)}`);
    } else if (discountCode.length > 0 && !discountData?.valid) {
      toast.error("Invalid discount code");
      setDiscountAmount(0);
    }
  }, [discountData]);

  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const calculateTotal = () => {
    return Math.max(0, calculateSubtotal() - discountAmount);
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !user) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
    };
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");

    try {
      const response = await sendMessageMutation.mutateAsync({
        content: inputValue,
      });

      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content: response.botResponse,
      };
      setMessages((prev) => [...prev, botMessage]);
      
      // Invalidate chat history to refresh from database
      await trpc.useUtils().chat.getHistory.invalidate();
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  const addToCart = (item: any) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.menuItemId === item.id);
      if (existing) {
        return prev.map((i) =>
          i.menuItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          menuItemId: item.id,
          name: item.name,
          price: parseFloat(item.price),
          quantity: 1,
          image: item.imageUrl || "",
        },
      ];
    });
    toast.success(`${item.name} added to cart!`);
  };

  const updateQuantity = (menuItemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(menuItemId);
    } else {
      setCart((prev) =>
        prev.map((i) =>
          i.menuItemId === menuItemId ? { ...i, quantity } : i
        )
      );
    }
  };

  const removeFromCart = (menuItemId: number) => {
    setCart((prev) => prev.filter((i) => i.menuItemId !== menuItemId));
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      toast.error("Your cart is empty");
      return;
    }

    try {
      const result = await createOrderMutation.mutateAsync({
        items: cart.map((item) => ({
          menuItemId: item.menuItemId,
          quantity: item.quantity,
        })),
        discountCode: discountCode || undefined,
      });

      toast.success(`Order created! Order ID: ${result.orderId}`);
      setCart([]);
      setDiscountCode("");
      setDiscountAmount(0);
      setShowOrderSummary(false);

      const confirmMessage: ChatMessage = {
        id: Date.now().toString(),
        type: "bot",
        content: `Great! Your order has been confirmed. Order total: $${result.totalPrice.toFixed(2)}. We'll prepare your food right away!`,
      };
      setMessages((prev) => [...prev, confirmMessage]);
    } catch (error: any) {
      toast.error(error.message || "Failed to create order");
    }
  };

  const categories = ["All", "Appetizers", "Mains", "Desserts", "Beverages"];
  const filteredItems =
    selectedCategory === "All"
      ? allMenuItems
      : allMenuItems?.filter((item) => item.category === selectedCategory);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gradient mb-2">
            🍽️ Food Ordering Chatbot
          </h1>
          <p className="text-muted-foreground">
            Welcome, {user?.name}! Browse our menu and order delicious food.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - Menu & Chat */}
          <div className="lg:col-span-2 space-y-6">
            {/* Menu Section */}
            <Card className="bg-card text-card-foreground rounded-lg shadow-md border border-border/30 p-6">
              <h2 className="text-2xl font-bold mb-4">Our Menu</h2>

              {/* Category Filter */}
              <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                {categories.map((cat) => (
                  <Button
                    key={cat}
                    variant={selectedCategory === cat ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(cat)}
                    className="whitespace-nowrap bg-accent text-accent-foreground hover:bg-accent/90"
                  >
                    {cat}
                  </Button>
                ))}
              </div>

              {/* Menu Items Grid */}
              {menuLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin w-8 h-8" />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {filteredItems?.map((item) => (
                    <div key={item.id} className="bg-card text-card-foreground rounded-lg shadow-md border border-border/30 overflow-hidden transition-transform duration-300 hover:scale-105 cursor-pointer">
                      {item.imageUrl && (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-48 object-cover"
                        />
                      )}
                      <div className="p-4">
                        <h3 className="font-bold text-lg mb-1">{item.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          {item.description}
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-lg font-bold text-accent">
                            ${parseFloat(item.price).toFixed(2)}
                          </span>
                          <Button
                            size="sm"
                            onClick={() => addToCart(item)}
                            className="bg-accent text-accent-foreground hover:bg-accent/90"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Add
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Chat Section */}
            <Card className="bg-card text-card-foreground rounded-lg shadow-md border border-border/30 p-6 h-96 flex flex-col">
              <h2 className="text-2xl font-bold mb-4">Chat Assistant</h2>

              {/* Messages Container */}
              <div className="flex-1 overflow-y-auto mb-4 space-y-3">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.type === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={
                        msg.type === "user"
                          ? "chat-bubble-user"
                          : "chat-bubble-bot"
                      }
                    >
                      <p className="text-sm">{msg.content}</p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Input Area */}
              <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleSendMessage()
                    }
                    placeholder="Ask me anything..."
                    className="flex-1"
                  />
                <Button
                  onClick={handleSendMessage}
                  disabled={sendMessageMutation.isPending}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  {sendMessageMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </Card>
          </div>

          {/* Sidebar - Order Summary */}
          <div className="lg:col-span-1">
            <Card className="bg-card text-card-foreground rounded-lg shadow-md border border-border/30 p-6 space-y-4 sticky top-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <ShoppingCart className="w-6 h-6" />
                  Cart
                </h2>
                <span className="bg-accent text-accent-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                  {cart.length}
                </span>
              </div>

              {/* Cart Items */}
              <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {cart.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    Your cart is empty
                  </p>
                ) : (
                  cart.map((item) => (
                    <div
                      key={item.menuItemId}
                      className="order-item"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-xs text-muted-foreground">
                          ${item.price.toFixed(2)} each
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            updateQuantity(item.menuItemId, item.quantity - 1)
                          }
                          className="h-6 w-6 p-0"
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-6 text-center text-sm font-medium">
                          {item.quantity}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            updateQuantity(item.menuItemId, item.quantity + 1)
                          }
                          className="h-6 w-6 p-0"
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeFromCart(item.menuItemId)}
                          className="h-6 w-6 p-0 text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Discount Code */}
              <div className="mb-4 space-y-2">
                <label className="text-sm font-medium">Discount Code</label>
                <div className="flex gap-2">
                  <Input
                    value={discountCode}
                    onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                    placeholder="Enter code"
                    className="flex-1 text-sm"
                  />
                </div>
              </div>

              {/* Price Summary */}
              {cart.length > 0 && (
                <>
                  <div className="price-row">
                    <span>Subtotal:</span>
                    <span>${calculateSubtotal().toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="price-row text-accent">
                      <span>Discount:</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="price-total">
                    <span>Total:</span>
                    <span>${calculateTotal().toFixed(2)}</span>
                  </div>
                </>
              )}

              {/* Checkout Button */}
              <Button
                onClick={handleCheckout}
                disabled={cart.length === 0 || createOrderMutation.isPending}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 mt-4"
              >
                {createOrderMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Checkout"
                )}
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
